# Daily Pen #80

A Pen created on CodePen.io. Original URL: [https://codepen.io/DylanMacnab/pen/NjVXEe](https://codepen.io/DylanMacnab/pen/NjVXEe).

Object-fit cover for background videos. It's a new CSS property for sizing background videos like background images. IE and Edge not supported.